
Cornhole Boards - v2 CornholeGameV1
==============================

This dataset was exported via roboflow.ai on September 27, 2021 at 4:27 PM GMT

It includes 112 images.
Cornhole-Boards are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)

The following augmentation was applied to create 3 versions of each source image:
* Random brigthness adjustment of between -54 and +54 percent
* Random Gaussian blur of between 0 and 5.5 pixels

The following transformations were applied to the bounding boxes of each image:
* Random rotation of between -20 and +20 degrees
* Random Gaussian blur of between 0 and 8.5 pixels


